// routes/directors.js
const express = require('express');
const db = require('../db/connection');
const multer = require('multer');
const path = require('path');

const router = express.Router();

// Configuración de multer para almacenar imágenes en la carpeta "imagenes"
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'imagenes/'); // Carpeta donde se guardarán las imágenes
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname)); // Nombre único para la imagen
  }
});

const upload = multer({ storage: storage });

// Crear un director con subida de imagen
router.post('/', upload.single('photo'), (req, res) => {
  const { name } = req.body;
  const photoUrl = `/imagenes/${req.file.filename}`; // URL de la imagen guardada localmente

  const sql = 'INSERT INTO directors (name, photoUrl) VALUES (?, ?)';
  db.query(sql, [name, photoUrl], (err, result) => {
    if (err) return res.status(500).send(err);
    res.json({ id: result.insertId, name, photoUrl });
  });
});

// Obtener todos los directores
router.get('/', (req, res) => {
  const sql = 'SELECT * FROM directors';
  db.query(sql, (err, result) => {
    if (err) return res.status(500).send(err);
    res.json(result);
  });
});

// Obtener un director por ID
router.get('/:id', (req, res) => {
  const sql = 'SELECT * FROM directors WHERE id = ?';
  db.query(sql, [req.params.id], (err, result) => {
    if (err) return res.status(500).send(err);
    if (result.length === 0) return res.status(404).send('Director no encontrado');
    res.json(result[0]);
  });
});

// Actualizar un director (con o sin imagen)
router.put('/:id', upload.single('photo'), (req, res) => {
  const { name } = req.body;
  let photoUrl;

  // Si se sube una nueva imagen, actualizar el campo photoUrl
  if (req.file) {
    photoUrl = `/imagenes/${req.file.filename}`;
  } else {
    photoUrl = req.body.photoUrl; // Mantener la imagen anterior si no se subió ninguna nueva
  }

  const sql = 'UPDATE directors SET name = ?, photoUrl = ? WHERE id = ?';
  db.query(sql, [name, photoUrl, req.params.id], (err, result) => {
    if (err) return res.status(500).send(err);
    res.json({ message: 'Director actualizado', name, photoUrl });
  });
});

// Eliminar un director
router.delete('/:id', (req, res) => {
  const sql = 'DELETE FROM directors WHERE id = ?';
  db.query(sql, [req.params.id], (err, result) => {
    if (err) return res.status(500).send(err);
    res.json({ message: 'Director eliminado' });
  });
});

module.exports = router;
