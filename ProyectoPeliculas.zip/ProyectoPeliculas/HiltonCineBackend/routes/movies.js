// routes/movies.js
const express = require('express');
const db = require('../db/connection');
const multer = require('multer');
const path = require('path');

const router = express.Router();

// Configuración de multer para almacenar imágenes en la carpeta "imagenes"
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'imagenes/'); // Carpeta donde se guardarán las imágenes
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname)); // Nombre único para la imagen
  }
});

const upload = multer({ storage: storage });

// Crear una película con actores y directores asociados
router.post('/', upload.single('image'), (req, res) => {
  const { name, synopsis, releaseDate, rottenTomatoes, trailerUrl, actorIds, directorIds } = req.body;
  const imageUrl = `/imagenes/${req.file.filename}`; // URL de la imagen guardada localmente

  // Insertar película en la base de datos
  const sql = 'INSERT INTO movies (name, synopsis, imageUrl, releaseDate, rottenTomatoes, trailerUrl) VALUES (?, ?, ?, ?, ?, ?)';
  
  db.query(sql, [name, synopsis, imageUrl, releaseDate, rottenTomatoes, trailerUrl], (err, result) => {
    if (err) return res.status(500).send(err);

    const movieId = result.insertId;

    // Insertar relaciones con actores
    const actorInsertQueries = actorIds ? JSON.parse(actorIds).map(actorId =>
      db.query('INSERT INTO movie_actors (movie_id, actor_id) VALUES (?, ?)', [movieId, actorId])
    ) : [];

    // Insertar relaciones con directores
    const directorInsertQueries = directorIds ? JSON.parse(directorIds).map(directorId =>
      db.query('INSERT INTO movie_directors (movie_id, director_id) VALUES (?, ?)', [movieId, directorId])
    ) : [];

    Promise.all([...actorInsertQueries, ...directorInsertQueries])
      .then(() => res.json({ id: movieId, name, synopsis, imageUrl, releaseDate, rottenTomatoes, trailerUrl }))
      .catch(err => res.status(500).send(err));
  });
});

// Obtener todas las películas con actores y directores asociados
router.get('/', (req, res) => {
  const sql = `
    SELECT movies.*, 
      GROUP_CONCAT(DISTINCT actors.name) AS actors,
      GROUP_CONCAT(DISTINCT directors.name) AS directors
    FROM movies
    LEFT JOIN movie_actors ON movies.id = movie_actors.movie_id
    LEFT JOIN actors ON actors.id = movie_actors.actor_id
    LEFT JOIN movie_directors ON movies.id = movie_directors.movie_id
    LEFT JOIN directors ON directors.id = movie_directors.director_id
    GROUP BY movies.id;
  `;
  db.query(sql, (err, result) => {
    if (err) return res.status(500).send(err);
    res.json(result);
  });
});

// Obtener una película por ID con actores y directores asociados
router.get('/:id', (req, res) => {
  const sql = `
    SELECT movies.*, 
      GROUP_CONCAT(DISTINCT actors.name) AS actors,
      GROUP_CONCAT(DISTINCT directors.name) AS directors
    FROM movies
    LEFT JOIN movie_actors ON movies.id = movie_actors.movie_id
    LEFT JOIN actors ON actors.id = movie_actors.actor_id
    LEFT JOIN movie_directors ON movies.id = movie_directors.movie_id
    LEFT JOIN directors ON directors.id = movie_directors.director_id
    WHERE movies.id = ?
    GROUP BY movies.id;
  `;
  db.query(sql, [req.params.id], (err, result) => {
    if (err) return res.status(500).send(err);
    if (result.length === 0) return res.status(404).send('Película no encontrada');
    res.json(result[0]);
  });
});

// Actualizar una película (con o sin nueva imagen) y sus asociaciones
router.put('/:id', upload.single('image'), (req, res) => {
  const { name, synopsis, releaseDate, rottenTomatoes, trailerUrl, actorIds, directorIds } = req.body;
  let imageUrl;

  // Si se sube una nueva imagen, actualizar el campo imageUrl
  if (req.file) {
    imageUrl = `/imagenes/${req.file.filename}`;
  } else {
    imageUrl = req.body.imageUrl; // Mantener la imagen anterior si no se subió una nueva
  }

  const sql = 'UPDATE movies SET name = ?, synopsis = ?, imageUrl = ?, releaseDate = ?, rottenTomatoes = ?, trailerUrl = ? WHERE id = ?';
  
  db.query(sql, [name, synopsis, imageUrl, releaseDate, rottenTomatoes, trailerUrl, req.params.id], (err, result) => {
    if (err) return res.status(500).send(err);

    const movieId = req.params.id;

    // Eliminar asociaciones anteriores de actores y directores
    db.query('DELETE FROM movie_actors WHERE movie_id = ?', [movieId], (err) => {
      if (err) return res.status(500).send(err);

      db.query('DELETE FROM movie_directors WHERE movie_id = ?', [movieId], (err) => {
        if (err) return res.status(500).send(err);

        // Insertar nuevas asociaciones con actores
        const actorInsertQueries = actorIds ? JSON.parse(actorIds).map(actorId =>
          db.query('INSERT INTO movie_actors (movie_id, actor_id) VALUES (?, ?)', [movieId, actorId])
        ) : [];

        // Insertar nuevas asociaciones con directores
        const directorInsertQueries = directorIds ? JSON.parse(directorIds).map(directorId =>
          db.query('INSERT INTO movie_directors (movie_id, director_id) VALUES (?, ?)', [movieId, directorId])
        ) : [];

        Promise.all([...actorInsertQueries, ...directorInsertQueries])
          .then(() => res.json({ message: 'Película actualizada correctamente', name, synopsis, imageUrl, releaseDate, rottenTomatoes, trailerUrl }))
          .catch(err => res.status(500).send(err));
      });
    });
  });
});

// Eliminar una película y sus asociaciones
router.delete('/:id', (req, res) => {
  const sql = 'DELETE FROM movies WHERE id = ?';
  db.query(sql, [req.params.id], (err, result) => {
    if (err) return res.status(500).send(err);
    res.json({ message: 'Película eliminada junto con sus asociaciones' });
  });
});

// Servir las imágenes desde la carpeta "imagenes"
router.use('/imagenes', express.static('imagenes'));

module.exports = router;
