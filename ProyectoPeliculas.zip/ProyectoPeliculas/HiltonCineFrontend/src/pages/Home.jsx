import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import MovieList from '../components/MovieList'; // Importar el componente MovieList
import movieService from '../services/movieService'; // Importar el servicio de películas

function Home() {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    // Cargar las películas desde el servicio cuando el componente se monta
    movieService.getAllMovies().then((data) => setMovies(data));
  }, []);

  return (
    <div className="container my-5">
      {/* Sección de Bienvenida y Navegación */}
      <h1 className="text-center mb-5">Bienvenido a HiltonCineFronted</h1>
      <div className="row text-center mb-5">
        <div className="col-md-4 mb-4">
          <Link to="/movies" className="btn btn-dark btn-lg w-100">
            Gestión de Películas
          </Link>
        </div>
        <div className="col-md-4 mb-4">
          <Link to="/actors" className="btn btn-dark btn-lg w-100">
            Gestión de Actores
          </Link>
        </div>
        <div className="col-md-4 mb-4">
          <Link to="/directors" className="btn btn-dark btn-lg w-100">
            Gestión de Directores
          </Link>
        </div>
      </div>

      {/* Lista de Películas Disponibles */}
      <h2 className="text-center mb-4">Películas Disponibles</h2>
      <div className="row justify-content-center">
        {movies.length > 0 ? (
          <MovieList movies={movies} /> // Renderizar la lista de películas
        ) : (
          <p className="text-center">No hay películas disponibles en este momento.</p>
        )}
      </div>
    </div>
  );
}

export default Home;
