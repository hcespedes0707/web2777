import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import actorService from '../services/actorService';
import movieService from '../services/movieService';

function ActorDetail() {
  const { id } = useParams();
  const [actor, setActor] = useState(null);
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    // Obtener detalles del actor por su ID
    actorService.getActorById(id).then((data) => {
      setActor(data);

      // Obtener todas las películas y filtrar las que pertenecen al actor
      movieService.getAllMovies().then((allMovies) => {
        if (data.movies && data.movies.length > 0) {
          const actorMovies = allMovies.filter((movie) =>
            data.movies.includes(movie.id)
          );
          setMovies(actorMovies);
        } else {
          setMovies([]); // Si el actor no tiene películas, establecer array vacío
        }
      });
    });
  }, [id]);

  if (!actor) return <p>Cargando...</p>; // Mostrar un mensaje mientras los datos se cargan

  return (
    <div className="container">
      <h1>{actor.name}</h1>
      {actor.photo && (
        <img
          src={`http://localhost:5000${actor.photo}`} // URL de la imagen del actor con el prefijo del servidor
          alt={actor.name}
          className="img-fluid mb-3"
          style={{ maxWidth: '300px' }}
        />
      )}
      <h3>Películas</h3>
      <div className="row">
        {movies.length > 0 ? (
          movies.map((movie) => (
            <div key={movie.id} className="col-md-4 mb-3">
              <div className="card">
                <img
                  src={`http://localhost:5000${movie.imageUrl || ''}`} // URL correcta de la imagen de la película
                  className="card-img-top"
                  alt={movie.name}
                  style={{ height: '300px', objectFit: 'cover' }}
                />
                <div className="card-body">
                  <h5 className="card-title">{movie.name}</h5>
                </div>
              </div>
            </div>
          ))
        ) : (
          <p>Este actor no ha participado en películas.</p>
        )}
      </div>
    </div>
  );
}

export default ActorDetail;
