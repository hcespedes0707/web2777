// src/pages/DirectorDetail.jsx
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import directorService from '../services/directorService';
import movieService from '../services/movieService';

function DirectorDetail() {
  const { id } = useParams();
  const [director, setDirector] = useState(null);
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    // Obtener el director por ID
    directorService.getDirectorById(id).then((data) => {
      setDirector(data);

      // Obtener todas las películas y filtrar las que pertenecen al director
      movieService.getAllMovies().then((allMovies) => {
        const directorMovies = allMovies.filter((movie) =>
          data.movies.includes(movie.id)
        );
        setMovies(directorMovies);
      });
    });
  }, [id]);

  if (!director) return <p>Cargando...</p>;

  return (
    <div className="container">
      <h1>{director.name}</h1>
      {director.photo && (
        <img
          src={`http://localhost:5000${director.photo}`}
          alt={director.name}
          className="img-fluid mb-3"
          style={{ maxWidth: '300px' }}
        />
      )}
      <h3>Películas</h3>
      <div className="row">
        {movies.length > 0 ? (
          movies.map((movie) => (
            <div key={movie.id} className="col-md-4">
              <div className="card">
                <img
                  src={`http://localhost:5000${movie.imageUrl}`} // Ajusta la ruta correcta de la imagen de la película
                  className="card-img-top"
                  alt={movie.name}
                />
                <div className="card-body">
                  <h5 className="card-title">{movie.name}</h5>
                </div>
              </div>
            </div>
          ))
        ) : (
          <p>Este director no tiene películas asociadas.</p>
        )}
      </div>
    </div>
  );
}

export default DirectorDetail;
