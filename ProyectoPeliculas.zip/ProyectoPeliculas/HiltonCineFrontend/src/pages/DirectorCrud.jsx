// src/pages/DirectorCrud.jsx
import { useState, useEffect } from 'react';
import directorService from '../services/directorService';

function DirectorCrud() {
  const [directors, setDirectors] = useState([]);
  const [newDirector, setNewDirector] = useState({
    name: '',
    photo: null, // Cambiar para almacenar el archivo en lugar de la URL
  });
  const [editingDirector, setEditingDirector] = useState(null);

  useEffect(() => {
    // Cargar los directores desde el servicio cuando el componente se monta
    directorService.getAllDirectors().then(setDirectors);
  }, []);

  const handleInputChange = (e) => {
    setNewDirector({
      ...newDirector,
      [e.target.name]: e.target.value,
    });
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setNewDirector({
      ...newDirector,
      photo: file, // Guardamos el archivo, no la URL
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('name', newDirector.name);
    if (newDirector.photo) {
      formData.append('photo', newDirector.photo);
    }

    if (editingDirector) {
      // Actualizar director existente
      directorService.updateDirector(editingDirector.id, formData).then((updatedDirector) => {
        setDirectors((prevDirectors) =>
          prevDirectors.map((director) =>
            director.id === updatedDirector.id ? updatedDirector : director
          )
        );
        setEditingDirector(null);
        setNewDirector({ name: '', photo: null });
      });
    } else {
      // Agregar nuevo director
      directorService.addDirector(formData).then((addedDirector) => {
        setDirectors([...directors, addedDirector]);
        setNewDirector({ name: '', photo: null });
      });
    }
  };

  const handleEdit = (director) => {
    setEditingDirector(director);
    setNewDirector({
      name: director.name,
      photo: null, // No cargamos la imagen actual, pero permitimos cambiarla
    });
  };

  const handleDelete = (id) => {
    directorService.deleteDirector(id).then(() => {
      setDirectors((prevDirectors) =>
        prevDirectors.filter((director) => director.id !== id)
      );
    });
  };

  return (
    <div className="container">
      <h1>Gestión de Directores</h1>

      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="name" className="form-label">Nombre</label>
          <input
            type="text"
            className="form-control"
            id="name"
            name="name"
            value={newDirector.name}
            onChange={handleInputChange}
            required
          />
        </div>

        <div className="mb-3">
          <label htmlFor="photo" className="form-label">Foto</label>
          <input
            type="file"
            className="form-control"
            id="photo"
            name="photo"
            onChange={handleFileChange}
            required={!editingDirector} // La foto es obligatoria solo al crear un director
          />
          {editingDirector && editingDirector.photo && (
            <img
              src={editingDirector.photo}
              alt="Director preview"
              className="img-thumbnail mt-3"
              style={{ maxWidth: '200px' }}
            />
          )}
        </div>

        <button type="submit" className="btn btn-primary">
          {editingDirector ? 'Actualizar Director' : 'Agregar Director'}
        </button>
      </form>

      <h2 className="mt-5">Lista de Directores</h2>
      <table className="table">
        <thead>
          <tr>
            <th>Foto</th>
            <th>Nombre</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {directors.map((director) => (
            <tr key={director.id}>
              <td>
                {director.photo && (
                  <img
                    src={`http://localhost:5000${director.photo}`} // Ruta correcta de la imagen
                    alt={director.name}
                    className="img-thumbnail"
                    style={{ maxWidth: '100px' }}
                  />
                )}
              </td>
              <td>{director.name}</td>
              <td>
                <button
                  className="btn btn-warning me-2"
                  onClick={() => handleEdit(director)}
                >
                  Editar
                </button>
                <button
                  className="btn btn-danger"
                  onClick={() => handleDelete(director.id)}
                >
                  Eliminar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default DirectorCrud;
