import { useState, useEffect } from 'react';
import actorService from '../services/actorService';  // Asegúrate de que actorService esté correctamente configurado

function ActorCrud() {
  const [actors, setActors] = useState([]);  // Estado para almacenar los actores
  const [newActor, setNewActor] = useState({
    name: '',
    photo: null,
  });
  const [editingActor, setEditingActor] = useState(null);  // Estado para manejar la edición de un actor

  // Cargar los actores cuando el componente se monta
  useEffect(() => {
    actorService.getAllActors().then(setActors);
  }, []);

  // Manejar cambios en el campo de texto
  const handleInputChange = (e) => {
    setNewActor({
      ...newActor,
      [e.target.name]: e.target.value || '',  // Garantiza que siempre haya un valor definido
    });
  };

  // Manejar la carga de archivos
  const handleFileChange = (e) => {
    const file = e.target.files[0] || null;  // Si no hay archivo, asigna null
    setNewActor({
      ...newActor,
      photo: file,
    });
  };

  // Manejar el envío del formulario
  const handleSubmit = (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('name', newActor.name);
    if (newActor.photo) {
      formData.append('photo', newActor.photo);  // Adjuntar el archivo solo si existe
    }

    if (editingActor) {
      // Actualizar actor existente
      actorService.updateActor(editingActor.id, formData)
        .then(updatedActor => {
          setActors(prevActors => prevActors.map(actor => actor.id === updatedActor.id ? updatedActor : actor));
          setEditingActor(null);
          setNewActor({ name: '', photo: null });
        })
        .catch(error => console.error('Error al actualizar actor:', error));
    } else {
      // Agregar nuevo actor
      actorService.addActor(formData)
        .then(addedActor => {
          setActors([...actors, addedActor]);
          setNewActor({ name: '', photo: null });
        })
        .catch(error => console.error('Error al agregar actor:', error));
    }
  };

  // Manejar la edición de un actor
  const handleEdit = (actor) => {
    setEditingActor(actor);
    setNewActor({
      name: actor.name || '',
      photo: null,  // No cargamos la foto actual, permitimos cambiarla
    });
  };

  // Manejar la eliminación de un actor
  const handleDelete = (id) => {
    actorService.deleteActor(id).then(() => {
      setActors(prevActors => prevActors.filter(actor => actor.id !== id));
    });
  };

  return (
    <div className="container">
      <h1>Gestión de Actores</h1>

      {/* Formulario de agregar/editar actor */}
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="name" className="form-label">Nombre</label>
          <input
            type="text"
            className="form-control"
            id="name"
            name="name"
            value={newActor.name}  // Enlazar el valor al estado de newActor
            onChange={handleInputChange}
            required
          />
        </div>

        <div className="mb-3">
          <label htmlFor="photo" className="form-label">Foto</label>
          <input
            type="file"
            className="form-control"
            id="photo"
            name="photo"
            onChange={handleFileChange}
            required={!editingActor}  // Requerir la imagen solo al agregar un actor nuevo
          />
          {/* Vista previa de la imagen al editar */}
          {editingActor && editingActor.photo && (
            <img
              src={`http://localhost:5000${editingActor.photo}`}
              alt="Vista previa del actor"
              className="img-thumbnail mt-3"
              style={{ maxWidth: '200px' }}
            />
          )}
        </div>

        <button type="submit" className="btn btn-primary">
          {editingActor ? 'Actualizar Actor' : 'Agregar Actor'}
        </button>
      </form>

      {/* Lista de actores */}
      <h2 className="mt-5">Lista de Actores</h2>
      <table className="table">
        <thead>
          <tr>
            <th>Foto</th>
            <th>Nombre</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {actors.map((actor, index) => (
            <tr key={actor.id || `actor-${index}`}>
              <td>
                {actor.photo && (
                  <img
                    src={`http://localhost:5000${actor.photo}`}
                    alt={actor.name}
                    className="img-thumbnail"
                    style={{ maxWidth: '100px' }}
                  />
                )}
              </td>
              <td>{actor.name}</td>
              <td>
                <button
                  className="btn btn-warning me-2"
                  onClick={() => handleEdit(actor)}
                >
                  Editar
                </button>
                <button
                  className="btn btn-danger"
                  onClick={() => handleDelete(actor.id)}
                >
                  Eliminar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ActorCrud;
