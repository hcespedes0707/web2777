import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import movieService from '../services/movieService';

function MovieDetail() {
  const { id } = useParams(); // Obtener el ID de la película desde la URL
  const [movie, setMovie] = useState(null);

  useEffect(() => {
    // Obtener la película por su ID desde el servicio
    movieService.getMovieById(id).then(setMovie);
  }, [id]);

  if (!movie) {
    return <p>Cargando detalles de la película...</p>; // Mostrar un mensaje mientras se carga la película
  }

  return (
    <div className="container mt-5">
      <div className="row">
        <div className="col-md-6">
          {movie.image ? (
            <img
              src={`http://localhost:5000${movie.image}`} // Asegurar que la URL de la imagen sea correcta
              alt={movie.name}
              className="img-fluid"
              style={{ maxHeight: '500px', objectFit: 'cover' }}
            />
          ) : (
            <p>Sin imagen disponible</p>
          )}
        </div>
        <div className="col-md-6">
          <h1>{movie.name}</h1>
          <p><strong>Sinopsis:</strong> {movie.synopsis}</p>
          <p><strong>Fecha de lanzamiento:</strong> {movie.releaseDate}</p>
          <p><strong>Calificación en Rotten Tomatoes:</strong> {movie.rottenTomatoes}%</p>
          <a href={movie.trailerUrl} target="_blank" rel="noopener noreferrer" className="btn btn-secondary">
            Ver Tráiler
          </a>
        </div>
      </div>
    </div>
  );
}

export default MovieDetail;
