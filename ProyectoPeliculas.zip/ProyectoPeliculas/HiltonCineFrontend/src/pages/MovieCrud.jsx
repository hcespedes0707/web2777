import { useState, useEffect } from 'react';
import movieService from '../services/movieService';

function MovieCrud() {
  const [movies, setMovies] = useState([]);
  const [newMovie, setNewMovie] = useState({
    name: '',
    image: null, // Cambiar a null para manejar archivos
    synopsis: '',
    releaseDate: '',
    rottenTomatoes: '',
    trailerUrl: '',
  });
  const [editingMovie, setEditingMovie] = useState(null);

  useEffect(() => {
    // Cargar las películas desde el servicio al montar el componente
    movieService.getAllMovies().then(setMovies);
  }, []);

  const handleInputChange = (e) => {
    setNewMovie({
      ...newMovie,
      [e.target.name]: e.target.value,
    });
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setNewMovie({
        ...newMovie,
        image: file, // Guardar el archivo en lugar de convertirlo a base64
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('name', newMovie.name);
    formData.append('synopsis', newMovie.synopsis);
    formData.append('releaseDate', newMovie.releaseDate);
    formData.append('rottenTomatoes', newMovie.rottenTomatoes);
    formData.append('trailerUrl', newMovie.trailerUrl);
    if (newMovie.image) {
      formData.append('image', newMovie.image); // Adjuntar el archivo solo si se ha seleccionado uno
    }

    if (editingMovie) {
      // Actualizar película existente
      movieService.updateMovie(editingMovie.id, formData).then((updatedMovie) => {
        setMovies((prevMovies) =>
          prevMovies.map((movie) =>
            movie.id === updatedMovie.id ? updatedMovie : movie
          )
        );
        resetForm();
      });
    } else {
      // Agregar nueva película
      movieService.addMovie(formData).then((addedMovie) => {
        setMovies([...movies, addedMovie]);
        resetForm();
      });
    }
  };

  const handleEdit = (movie) => {
    setEditingMovie(movie);
    setNewMovie({
      name: movie.name,
      image: null, // No cargamos la imagen existente en el campo de archivo
      synopsis: movie.synopsis,
      releaseDate: movie.releaseDate,
      rottenTomatoes: movie.rottenTomatoes,
      trailerUrl: movie.trailerUrl,
    });
  };

  const handleDelete = (id) => {
    movieService.deleteMovie(id).then(() => {
      setMovies((prevMovies) =>
        prevMovies.filter((movie) => movie.id !== id)
      );
    });
  };

  const resetForm = () => {
    setNewMovie({
      name: '',
      image: null,
      synopsis: '',
      releaseDate: '',
      rottenTomatoes: '',
      trailerUrl: '',
    });
    setEditingMovie(null);
  };

  return (
    <div className="container">
      <h1>Gestión de Películas</h1>

      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="name" className="form-label">Nombre</label>
          <input
            type="text"
            className="form-control"
            id="name"
            name="name"
            value={newMovie.name}
            onChange={handleInputChange}
            required
          />
        </div>

        <div className="mb-3">
          <label htmlFor="synopsis" className="form-label">Sinopsis</label>
          <textarea
            className="form-control"
            id="synopsis"
            name="synopsis"
            value={newMovie.synopsis}
            onChange={handleInputChange}
            required
          />
        </div>

        <div className="mb-3">
          <label htmlFor="image" className="form-label">Imagen</label>
          <input
            type="file"
            className="form-control"
            id="image"
            name="image"
            onChange={handleFileChange}
            required={!editingMovie} // La imagen solo es requerida al agregar una nueva película
          />
          {newMovie.image && (
            <img
              src={URL.createObjectURL(newMovie.image)} // Previsualizar la imagen seleccionada
              alt="Vista previa"
              className="img-thumbnail mt-3"
              style={{ maxWidth: '200px' }}
            />
          )}
        </div>

        <div className="mb-3">
          <label htmlFor="releaseDate" className="form-label">Fecha de Lanzamiento</label>
          <input
            type="date"
            className="form-control"
            id="releaseDate"
            name="releaseDate"
            value={newMovie.releaseDate}
            onChange={handleInputChange}
            required
          />
        </div>

        <div className="mb-3">
          <label htmlFor="rottenTomatoes" className="form-label">Calificación en Rotten Tomatoes</label>
          <input
            type="number"
            className="form-control"
            id="rottenTomatoes"
            name="rottenTomatoes"
            value={newMovie.rottenTomatoes}
            onChange={handleInputChange}
            required
          />
        </div>

        <div className="mb-3">
          <label htmlFor="trailerUrl" className="form-label">URL del Tráiler</label>
          <input
            type="url"
            className="form-control"
            id="trailerUrl"
            name="trailerUrl"
            value={newMovie.trailerUrl}
            onChange={handleInputChange}
            required
          />
        </div>

        <button type="submit" className="btn btn-primary">
          {editingMovie ? 'Actualizar Película' : 'Agregar Película'}
        </button>
      </form>

      <h2 className="mt-5">Lista de Películas</h2>
      <table className="table">
        <thead>
          <tr>
            <th>Imagen</th>
            <th>Nombre</th>
            <th>Sinopsis</th>
            <th>Fecha de Lanzamiento</th>
            <th>Calificación</th>
            <th>Tráiler</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {movies.map((movie) => (
            <tr key={movie.id}>
              <td>
                {movie.image && (
                  <img
                    src={`http://localhost:5000${movie.image}`} // Asegurar que la URL de la imagen sea correcta
                    alt={movie.name}
                    className="img-thumbnail"
                    style={{ maxWidth: '100px' }}
                  />
                )}
              </td>
              <td>{movie.name}</td>
              <td>{movie.synopsis}</td>
              <td>{movie.releaseDate}</td>
              <td>{movie.rottenTomatoes}%</td>
              <td>
                <a href={movie.trailerUrl} target="_blank" rel="noopener noreferrer">
                  Ver Tráiler
                </a>
              </td>
              <td>
                <button
                  className="btn btn-warning me-2"
                  onClick={() => handleEdit(movie)}
                >
                  Editar
                </button>
                <button
                  className="btn btn-danger"
                  onClick={() => handleDelete(movie.id)}
                >
                  Eliminar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default MovieCrud;
