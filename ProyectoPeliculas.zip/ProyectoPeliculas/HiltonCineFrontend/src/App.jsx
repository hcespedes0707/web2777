import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Home from './pages/Home';
import MovieDetail from './pages/MovieDetail';
import ActorDetail from './pages/ActorDetail';
import DirectorDetail from './pages/DirectorDetail';
import MovieCrud from './pages/MovieCrud';
import ActorCrud from './pages/ActorCrud';
import DirectorCrud from './pages/DirectorCrud';
import NotFound from './pages/NotFound'; // Página 404

// Componente Navbar
function Navbar() {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container-fluid">
        <Link className="navbar-brand" to="/">HiltonCineFronted</Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <Link className="nav-link" to="/">Inicio</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/movies">CRUD Películas</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/actors">CRUD Actores</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/directors">CRUD Directores</Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}

function App() {
  return (
    <Router>
      <div>
        <Navbar /> {/* Navbar extraído como componente */}

        {/* Definir las rutas */}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/movie/:id" element={<MovieDetail />} />
          <Route path="/actor/:id" element={<ActorDetail />} />
          <Route path="/director/:id" element={<DirectorDetail />} />
          <Route path="/movies" element={<MovieCrud />} />
          <Route path="/actors" element={<ActorCrud />} />
          <Route path="/directors" element={<DirectorCrud />} />
          <Route path="*" element={<NotFound />} /> {/* Ruta para manejar 404 */}
        </Routes>
      </div>
    </Router>
  );
}

export default App;
