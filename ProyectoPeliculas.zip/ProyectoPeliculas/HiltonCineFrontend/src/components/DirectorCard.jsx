import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

function DirectorCard({ director }) {
  const defaultPhoto = 'https://via.placeholder.com/300x400.png?text=Sin+Foto'; // Imagen predeterminada si no hay foto

  return (
    <div className="card h-100 shadow-sm">
      <img
        src={director.photo ? `http://localhost:5000${director.photo}` : defaultPhoto} // URL correcta o imagen predeterminada
        className="card-img-top"
        alt={director.name}
        style={{ height: '300px', objectFit: 'cover' }}
      />
      <div className="card-body d-flex flex-column">
        <h5 className="card-title">{director.name}</h5>
        <p className="card-text">
          Ha dirigido {director.movies.length} película(s).
        </p>
        <Link to={`/director/${director.id}`} className="btn btn-primary mt-auto">
          Ver detalles
        </Link>
      </div>
    </div>
  );
}

// Definir los tipos de las props usando PropTypes
DirectorCard.propTypes = {
  director: PropTypes.shape({
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired,
    photo: PropTypes.string, // Hacemos la foto opcional
    movies: PropTypes.arrayOf(PropTypes.number).isRequired,
  }).isRequired,
};

export default DirectorCard;
