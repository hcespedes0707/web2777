import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

function ActorCard({ actor }) {
  const defaultPhoto = 'https://via.placeholder.com/300x400.png?text=Sin+Foto'; // Imagen predeterminada

  return (
    <div className="card h-100 shadow-sm">
      <img
        src={actor.photoUrl ? `http://localhost:5000${actor.photoUrl}` : defaultPhoto} // Asegúrate de que estás usando 'photoUrl'
        className="card-img-top"
        alt={actor.name}
        style={{ height: '300px', objectFit: 'cover' }}
      />
      <div className="card-body d-flex flex-column">
        <h5 className="card-title">{actor.name}</h5>
        <Link to={`/actor/${actor.id}`} className="btn btn-primary mt-auto">
          Ver detalles
        </Link>
      </div>
    </div>
  );
}

ActorCard.propTypes = {
  actor: PropTypes.shape({
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired,
    photoUrl: PropTypes.string, // Asegúrate de usar 'photoUrl'
  }).isRequired,
};

export default ActorCard;
