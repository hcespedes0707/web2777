import PropTypes from 'prop-types';
import ActorCard from './ActorCard';

function ActorList({ actors }) {
  if (!actors || actors.length === 0) {
    return <p>No hay actores disponibles.</p>; // Mensaje cuando no hay actores
  }

  return (
    <div className="row">
      {actors.map((actor) => (
        <div key={actor.id} className="col-md-4 mb-4">
          <ActorCard actor={actor} />
        </div>
      ))}
    </div>
  );
}

// Definir los tipos de las props usando PropTypes
ActorList.propTypes = {
  actors: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.number.isRequired,
      name: PropTypes.string.isRequired,
      photo: PropTypes.string, // Foto opcional
      movies: PropTypes.arrayOf(PropTypes.number), // Hacemos movies opcional para manejar la ausencia
    })
  ).isRequired,
};

export default ActorList;
