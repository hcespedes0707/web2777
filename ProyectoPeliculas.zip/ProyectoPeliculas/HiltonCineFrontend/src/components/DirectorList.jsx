// src/components/DirectorList.jsx
import PropTypes from 'prop-types';
import DirectorCard from './DirectorCard';

function DirectorList({ directors }) {
  return (
    <div className="row">
      {directors.map((director) => (
        <div key={director.id} className="col-md-4 mb-4">
          <DirectorCard director={director} />
        </div>
      ))}
    </div>
  );
}

// Definir los tipos de las props usando PropTypes
DirectorList.propTypes = {
  directors: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.number.isRequired,
      name: PropTypes.string.isRequired,
      photo: PropTypes.string.isRequired,
      movies: PropTypes.arrayOf(PropTypes.number).isRequired,
    })
  ).isRequired,
};

export default DirectorList;
