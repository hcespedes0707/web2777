import PropTypes from 'prop-types';
import MovieCard from './MovieCard';

function MovieList({ movies }) {
  return (
    <div className="row">
      {movies.map((movie) => (
        <div key={movie.id} className="col-md-4 mb-4">
          <MovieCard movie={movie} />
        </div>
      ))}
    </div>
  );
}

MovieList.propTypes = {
  movies: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.number.isRequired,
      name: PropTypes.string.isRequired,
      image: PropTypes.string, // Hacemos la imagen opcional
      synopsis: PropTypes.string.isRequired,
      releaseDate: PropTypes.string.isRequired,
      rottenTomatoes: PropTypes.number.isRequired,
      trailerUrl: PropTypes.string.isRequired, // Validamos que el tráiler sea una cadena
    })
  ).isRequired,
};

export default MovieList;
