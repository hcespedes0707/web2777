import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

function MovieCard({ movie }) {
  const defaultImage = 'https://via.placeholder.com/300x400.png?text=Sin+Imagen'; // Imagen por defecto si no hay imagen

  return (
    <div className="card h-100 shadow-sm">
      <img
        src={movie.image ? `http://localhost:5000${movie.image}` : defaultImage} // Verificar si la imagen está disponible
        className="card-img-top"
        alt={movie.name}
        style={{ height: '300px', objectFit: 'cover' }}
      />
      <div className="card-body d-flex flex-column">
        <h5 className="card-title">{movie.name}</h5>
        <p className="card-text">{movie.synopsis}</p>
        <Link to={`/movie/${movie.id}`} className="btn btn-primary mt-auto mb-2">
          Ver detalles
        </Link>
        <a href={movie.trailerUrl} target="_blank" rel="noopener noreferrer" className="btn btn-secondary">
          Ver Tráiler
        </a>
      </div>
    </div>
  );
}

MovieCard.propTypes = {
  movie: PropTypes.shape({
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired,
    image: PropTypes.string, // Hacemos la imagen opcional
    synopsis: PropTypes.string.isRequired,
    releaseDate: PropTypes.string.isRequired,
    rottenTomatoes: PropTypes.number.isRequired,
    trailerUrl: PropTypes.string.isRequired, // Validamos que el tráiler sea una cadena
  }).isRequired,
};

export default MovieCard;
