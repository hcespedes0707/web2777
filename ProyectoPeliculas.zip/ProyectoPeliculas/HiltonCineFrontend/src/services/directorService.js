const directors = [
  {
    id: 1,
    name: 'Christopher Nolan',
    photo: '/path/to/nolan.jpg',
    movies: [1], // IDs de películas asociadas
  },
  // más directores...
];

const directorService = {
  // Obtener todos los directores
  getAllDirectors: () => Promise.resolve(directors),
  
  // Obtener un director por ID
  getDirectorById: (id) => Promise.resolve(directors.find((director) => director.id === parseInt(id))),

  // Agregar un nuevo director
  addDirector: (director) => {
    director.id = directors.length + 1; // Asignar nuevo ID
    directors.push(director); // Agregar a la lista
    return Promise.resolve(director);
  },

  // Actualizar un director existente
  updateDirector: (id, updatedData) => {
    const directorIndex = directors.findIndex((director) => director.id === parseInt(id));
    if (directorIndex !== -1) {
      directors[directorIndex] = { ...directors[directorIndex], ...updatedData };
      return Promise.resolve(directors[directorIndex]);
    }
    return Promise.reject('Director no encontrado');
  },

  // Eliminar un director
  deleteDirector: (id) => {
    const directorIndex = directors.findIndex((director) => director.id === parseInt(id));
    if (directorIndex !== -1) {
      directors.splice(directorIndex, 1);
      return Promise.resolve(true);
    }
    return Promise.reject('Director no encontrado');
  },
};

export default directorService;
