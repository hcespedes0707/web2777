const baseUrl = 'http://localhost:5000/api/actors'; // URL del backend

const actorService = {
  // Obtener todos los actores
  getAllActors: () => {
    return fetch(baseUrl)
      .then(response => {
        if (!response.ok) {
          throw new Error('Error al obtener actores');
        }
        return response.json();
      })
      .catch(error => {
        console.error('Error al obtener actores:', error);
        throw error;
      });
  },

  // Obtener un actor por su ID
  getActorById: (id) => {
    return fetch(`${baseUrl}/${id}`)
      .then(response => {
        if (!response.ok) {
          throw new Error('Error al obtener actor');
        }
        return response.json();
      })
      .catch(error => {
        console.error('Error al obtener actor:', error);
        throw error;
      });
  },

  // Agregar un nuevo actor con FormData (maneja la imagen)
  addActor: (formData) => {
    return fetch(baseUrl, {
      method: 'POST',
      body: formData,  // Usamos FormData para manejar archivos
    })
      .then(response => {
        if (!response.ok) {
          throw new Error('Error al agregar actor');
        }
        return response.json();
      })
      .catch(error => {
        console.error('Error al agregar actor:', error);
        throw error;
      });
  },

  // Actualizar un actor existente con FormData
  updateActor: (id, formData) => {
    return fetch(`${baseUrl}/${id}`, {
      method: 'PUT',
      body: formData,  // Usamos FormData para manejar archivos y texto
    })
      .then(response => {
        if (!response.ok) {
          throw new Error('Error al actualizar actor');
        }
        return response.json();
      })
      .catch(error => {
        console.error('Error al actualizar actor:', error);
        throw error;
      });
  },

  // Eliminar un actor por ID
  deleteActor: (id) => {
    return fetch(`${baseUrl}/${id}`, {
      method: 'DELETE',
    })
      .then(response => {
        if (!response.ok) {
          throw new Error('Error al eliminar actor');
        }
        return response.json();
      })
      .catch(error => {
        console.error('Error al eliminar actor:', error);
        throw error;
      });
  },
};

export default actorService;
