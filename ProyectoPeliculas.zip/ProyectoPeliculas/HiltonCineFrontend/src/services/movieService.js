let movies = [
  {
    id: 1,
    name: 'Inception',
    image: 'https://path-to-image/inception.jpg',
    synopsis: 'A thief who steals corporate secrets through dream-sharing technology...',
    releaseDate: '2010-07-16',
    rottenTomatoes: 87,
    trailerUrl: 'https://www.youtube.com/watch?v=8hP9D6kZseM',
  },
  // Más películas...
];

const movieService = {
  // Obtener todas las películas
  getAllMovies: () => {
    return new Promise((resolve) => {
      setTimeout(() => resolve(movies), 500); // Simulamos una pequeña demora
    });
  },

  // Obtener película por ID
  getMovieById: (id) => {
    return new Promise((resolve, reject) => {
      const movie = movies.find((movie) => movie.id === parseInt(id));
      setTimeout(() => {
        movie ? resolve(movie) : reject('Película no encontrada');
      }, 500);
    });
  },

  // Agregar una nueva película
  addMovie: (movie) => {
    const newId = movies.length ? Math.max(...movies.map((m) => m.id)) + 1 : 1; // Generamos un ID único
    const newMovie = { ...movie, id: newId };
    movies.push(newMovie);
    return new Promise((resolve) => {
      setTimeout(() => resolve(newMovie), 500);
    });
  },

  // Actualizar una película existente
  updateMovie: (id, updatedMovie) => {
    return new Promise((resolve, reject) => {
      const index = movies.findIndex((movie) => movie.id === parseInt(id));
      if (index !== -1) {
        movies[index] = { ...updatedMovie, id }; // Actualizar la película
        setTimeout(() => resolve(movies[index]), 500);
      } else {
        reject('Película no encontrada');
      }
    });
  },

  // Eliminar una película
  deleteMovie: (id) => {
    return new Promise((resolve, reject) => {
      const movieExists = movies.some((movie) => movie.id === parseInt(id));
      if (movieExists) {
        movies = movies.filter((movie) => movie.id !== parseInt(id));
        setTimeout(() => resolve(), 500);
      } else {
        reject('Película no encontrada');
      }
    });
  },
};

export default movieService;
