const db = require('../models');


// Listar hamburguesas
// Listar hamburguesas con el restaurante asociado
exports.listhamburguesas = async function (req, res) {
    try {
        const hamburguesas = await db.hamburguesas.findAll({
            include: {
                model: db.restaurantes,
                as: 'restaurante' // Alias definido en la relación
            }
        });
        res.render('hamburguesas/list.ejs', { hamburguesas });
    } catch (error) {
        console.error('Error al listar hamburguesas:', error);
        res.status(500).send('Error al listar hamburguesas');
    }
};


// Mostrar formulario de creación
exports.createhamburguesas = async function (req, res) {
	const restaurantes = await db.restaurantes.findAll();
	res.render('hamburguesas/form.ejs', { hamburguesas: null,restaurantes });
};

// Insertar nueva hamburguesa
exports.inserthamburguesas = async function (req, res) {
	try {
		await db.hamburguesas.create({
			nombre: req.body.nombre,
			descripcion: req.body.descripcion,
			restauranteId: req.body.restauranteId
		});
		res.redirect('/hamburguesas');
	} catch (error) {
		console.error('Error al insertar hamburguesa:', error);
		res.status(500).send('Error al insertar hamburguesa');
	}
};

// Mostrar formulario de edición
exports.edithamburguesas = async function (req, res) {
	const id = req.params.id;
	try {
		const hamburguesas = await db.hamburguesas.findByPk(id);
		const restaurantes = await db.restaurantes.findAll();
		if (hamburguesas) {
			res.render('hamburguesas/form.ejs', { hamburguesas,restaurantes });
		} else {
			res.status(404).send('Hamburguesa no encontrada');
		}
	} catch (error) {
		console.error('Error al cargar hamburguesa para editar:', error);
		res.status(500).send('Error al cargar hamburguesa para editar');
	}
};

// Actualizar hamburguesa existente
exports.updatehamburguesas = async function (req, res) {
	const id = req.params.id;
	const restaurantes = await db.restaurantes.findAll();
	try {
		const hamburguesas = await db.hamburguesas.findByPk(id);
		if (hamburguesas) {
			hamburguesas.nombre = req.body.nombre;
			hamburguesas.descripcion = req.body.descripcion;
			hamburguesas.restauranteId = req.body.restauranteId;
			await hamburguesas.save();
			res.redirect('/hamburguesas');
		} else {
			res.status(404).send('Hamburguesa no encontrada');
		}
	} catch (error) {
		console.error('Error al actualizar hamburguesa:', error);
		res.status(500).send('Error al actualizar hamburguesa');
	}
};

// Eliminar hamburguesa
exports.deletehamburguesas = async function (req, res) {
	const id = req.params.id;
	try {
		const hamburguesas = await db.hamburguesas.findByPk(id);
		if (hamburguesas) {
			await hamburguesas.destroy();
			res.redirect('/hamburguesas');
		} else {
			res.status(404).send('Hamburguesa no encontrada');
		}
	} catch (error) {
		console.error('Error al eliminar hamburguesa:', error);
		res.status(500).send('Error al eliminar hamburguesa');
	}
};

exports.uploadProfileGet = async function (req, res) {
	const id = req.params.id;
	const hamburguesas = await db.hamburguesas.findByPk(id);
	res.render('hamburguesas/uploadProfile.ejs', { hamburguesas , errors: null });
};

exports.uploadProfilePost = async function (req, res) {
	

    const id = req.params.id;
    const hamburguesas = await db.hamburguesas.findByPk(id);
    if (!req.files?.photo) {
        res.render('hamburguesas/uploadProfile.ejs', { errors: { message: 'Debe seleccionar una imagen' }, hamburguesas });
        return;
    }
    const image = req.files.photo;
    // eslint-disable-next-line no-undef
    const path = __dirname + '/../public/images/profile/' + hamburguesas.id + '.jpg';

    image.mv(path, function (err) {
        if (err) {
            res.render('hamburguesas/uploadProfile.ejs', { errors: { message: 'Error al subir la imagen' }, hamburguesas });
            console.log(err);
            return;
        }
        res.redirect('/hamburguesas');
    });
}
