
const db = require('../models');
exports.listrestaurantes= function(req, res){
	db.restaurantes.findAll().then(restaurantes => {
	res.render('restaurantes/list.ejs', {restaurantes: restaurantes});
	});
    }

	exports.createrestaurantes= function(req, res){
		res.render('restaurantes/form.ejs', {restaurantes: null});
		}

		exports.insertrestaurantes= function(req, res){
			db.restaurantes.create({
				nombre: req.body.nombre
			}).then(() => {
				res.redirect('/restaurantes');
			});
		}

		exports.editrestaurantes= function(req, res){
			const id = req.params.id;
			db.restaurantes.findByPk(id).then(restaurantes => {
				res.render('restaurantes/form.ejs', {restaurantes: restaurantes});
			});
		}

		exports.updaterestaurantes= function(req, res){
			const id = req.params.id;
			db.restaurantes.findByPk(id).then(restaurantes => {
				restaurantes.nombre = req.body.nombre;
				restaurantes.save().then(() => {
					res.redirect('/restaurantes');
				});
			});
		}

		exports.deleterestaurantes= function(req, res){
			const id = req.params.id;
			db.restaurantes.findByPk(id).then(restaurantes => {
				restaurantes.destroy().then(() => {
					res.redirect('/restaurantes');
				});
			});
		}
