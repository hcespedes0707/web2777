module.exports = app => {
    let router = require("express").Router();
    const controller = require("../controllers/hamburguesas.controllers.js");
    router.get("/",controller.listhamburguesas);
    router.get("/create",controller.createhamburguesas);
    router.post("/create",controller.inserthamburguesas);

    router.get("/:id/edit",controller.edithamburguesas);
    router.post("/:id/edit",controller.updatehamburguesas);

    router.post("/:id/delete",controller.deletehamburguesas);


    router.get("/:id/profile",controller.uploadProfileGet);
    router.post("/:id/profile",controller.uploadProfilePost);

    app.use('/hamburguesas', router);
};
