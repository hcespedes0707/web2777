module.exports = app => {
    let router = require("express").Router();
    const controller = require("../controllers/restaurantes.controllers.js");
    router.get("/",controller.listrestaurantes);
    router.get("/create",controller.createrestaurantes);
    router.post("/create",controller.insertrestaurantes);

    router.get("/:id/edit",controller.editrestaurantes);
    router.post("/:id/edit",controller.updaterestaurantes);

    router.post("/:id/delete",controller.deleterestaurantes);  

    app.use('/restaurantes', router);
};
