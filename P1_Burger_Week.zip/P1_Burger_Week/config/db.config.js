module.exports = {
    HOST: "localhost",
    USER:"root",
    PASSWORD: "",
    DB:"burger_week",
    PORT: 3306
}