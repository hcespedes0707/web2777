module.exports = (sequelize, Sequelize) => {
    const Restaurante = sequelize.define("restaurante", {
       
        nombre: {
            type: Sequelize.STRING
        }
    });
    return Restaurante;
};
    