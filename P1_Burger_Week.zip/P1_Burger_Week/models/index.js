const dbConfig = require("../config/db.config.js");
const Sequelize = require("sequelize");
const sequelize = new Sequelize(dbConfig.DB,
     dbConfig.USER,
      dbConfig.PASSWORD, {
    host: dbConfig.HOST,
    port: dbConfig.PORT,    
    dialect: "mysql",
      }
);

const db = {};
db.Sequelize = Sequelize;
db.sequelize = sequelize;
db.restaurantes = require("./restaurante.model.js")(sequelize, Sequelize);
db.hamburguesas = require("./hamburguesa.model.js")(sequelize,Sequelize);
db.restaurantes.hasMany(db.hamburguesas, { as: "hamburguesas" });
db.hamburguesas.belongsTo(db.restaurantes, {
  foreignKey: "restauranteId",
  as: "restaurante",
});




module.exports = db;
