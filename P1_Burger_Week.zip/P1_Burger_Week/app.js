// 1 - Invocamos a Express
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const fileUpload = require('express-fileupload');

app.use(fileUpload({
    limits: { fileSize: 50 * 1024 * 1024 },
}));

//2 - Para poder capturar los datos del formulario (sin urlencoded nos devuelve "undefined")
app.use(bodyParser.urlencoded({extended:false}));
app.use(express.json());//además le decimos a express que vamos a usar json
app.use('/images', express.static('public/images'));

//3- Invocamos a dotenv
const dotenv = require('dotenv');
dotenv.config({ path: './env/.env'});

//4 -seteamos el directorio de assets
app.use('/resources',express.static('public'));

//5 - Establecemos el motor de plantillas
app.set('view engine','ejs');
app.use(express.static('publico'));






//6 -Invocamos a bcrypt
const bcrypt = require('bcryptjs');

//7- variables de session
const session = require('express-session');
app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));


// 8 - Invocamos a la conexion de la DB
const connection = require('./database/db');

//9 - establecemos las rutas
	app.get('/login',(req, res)=>{
		res.render('login');
	})

	app.get('/register',(req, res)=>{
		res.render('register');
	})




//10 - Método para la REGISTRACIÓN
app.post('/register', async (req, res)=>{
	const user = req.body.user;
	const name = req.body.name;
    const rol = req.body.rol;
	const pass = req.body.pass;
	let passwordHash = await bcrypt.hash(pass, 8);
    connection.query('INSERT INTO users SET ?',{user:user, name:name, rol:rol, pass:passwordHash}, async (error, results)=>{
        if(error){
            console.log(error);
        }else{            
			res.render('register', {
				alert: true,
				alertTitle: "Registration",
				alertMessage: "¡Successful Registration!",
				alertIcon:'success',
				showConfirmButton: false,
				timer: 1500,
				ruta: ''
			});
            //res.redirect('/');         
        }
	});
})

require('./routes')(app);

app.get('/restaurantes/create',function(req, res){
	res.render('restaurantes/form.ejs', {restaurantes: null});
});
app.post('/restaurantes/create',function(req, res){
	db.restaurantes.create({
		nombre: req.body.nombre
	}).then(() => {
		res.redirect('/restaurantes');
	});
});



//
app.get('/restaurantes/:id/edit',async function(req, res){
	const id = req.params.id;
	const restaurantes = await db.restaurantes.findByPk(id);
	res.render('restaurantes/form.ejs', {restaurantes: restaurantes});
});
app.post('/restaurantes/:id/edit',async function(req, res){

	const id = req.params.id;
	const restaurantes = await db.restaurantes.findByPk(id);

	restaurantes.nombre = req.body.nombre;
	await restaurantes.save();
	res.redirect('/restaurantes');
});
app.post('/restaurantes/:id/delete',async function(req, res){
	const id = req.params.id;
	const restaurantes = await db.restaurantes.findByPk(id);
	await restaurantes.destroy();
	res.redirect('/restaurantes');
});


//
//11 - Metodo para la autenticacion
app.post('/auth', async (req, res)=> {
	const user = req.body.user;
	const pass = req.body.pass;    
    let passwordHash = await bcrypt.hash(pass, 8);
	if (user && pass) {
		connection.query('SELECT * FROM users WHERE user = ?', [user], async (error, results, fields)=> {
			if( results.length == 0 || !(await bcrypt.compare(pass, results[0].pass)) ) {    
				res.render('login', {
                        alert: true,
                        alertTitle: "Error",
                        alertMessage: "USUARIO y/o PASSWORD incorrectas",
                        alertIcon:'error',
                        showConfirmButton: true,
                        timer: false,
                        ruta: 'login'    
                    });
				
				//Mensaje simple y poco vistoso
                //res.send('Incorrect Username and/or Password!');				
			} else {         
				//creamos una var de session y le asignamos true si INICIO SESSION       
				req.session.loggedin = true;                
				req.session.name = results[0].name;
				res.render('login', {
					alert: true,
					alertTitle: "Conexión exitosa",
					alertMessage: "¡LOGIN CORRECTO!",
					alertIcon:'success',
					showConfirmButton: false,
					timer: 1500,
					ruta: 'restaurantes'
				});        			
			}			
			res.end();
		});
	} else {	
		res.send('Please enter user and Password!');
		res.end();
	}
});

//12 - Método para controlar que está auth en todas las páginas
app.get('/login', (req, res)=> {
	if (req.session.loggedin) {
		res.render('login',{
			login: true,
			name: req.session.name			
			
		});		
	} else {
		res.render('index',{
			login:false,
			name:'Debe iniciar sesión',			
		});				
	}
	res.end();
});


//función para limpiar la caché luego del logout
app.use(function(req, res, next) {
    if (!req.user)
        res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    next();
});

 //Logout
//Destruye la sesión.
app.get('/logout', function (req, res) {
	req.session.destroy(() => {
	  res.redirect('/login') // siempre se ejecutará después de que se destruya la sesión
	})
});


const db = require("./models");

db.sequelize.sync().then(() => {
console.log("Drop and re-sync db.");
});




app.listen(3000, (req, res)=>{
    console.log('SERVER RUNNING IN http://localhost:3000/login');
});